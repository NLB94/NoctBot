module.exports = {
    token: "NzM1ODI0MzY3Njk4ODM3NTU1.Xxl32A.q7-g-KCVuOQ_xL7_k-QWTc49gnk",
    ownerID: "616547009750499358",
    DBCONNECTION: "mongodb+srv://i2z7:Mongodb_94@i2z7.enhwf.mongodb.net/I2Z7-G-U?retryWrites=true&w=majority",
    DBL_TOKEN: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjczNTgyNDM2NzY5ODgzNzU1NSIsImJvdCI6dHJ1ZSwiaWF0IjoxNjA5ODc3MjY1fQ.2_va2ql0HcKZPI86NxBMsuAMQXVtiSfQjNKHvrti8SU",
    DEFAULTSETTINGS: {
        prefix: "~",
        logs: "logs",
        wChannel: "",
        wMessage: "・━━━━━━━━━━━━━━━・ \n🎉 **Welcome  {user} in {server}** ! 🎉 \n・━━━━━━━━━━━━━━━・ \n🎉We are now **{memberCount}🎉** \n・━━━━━━━━━━━━━━━・",
        wRole: "",
        lChannel: "",
        lMessage: "・━━━━━━━━━━━━━━━・\n😢 **{user} left {server}**  😢 !  \n・━━━━━━━━━━━━━━━・",
        levelUpMessage: "GG {user} you leveled up to {level}",
    }
}