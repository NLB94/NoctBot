module.exports = {
    Guild: require("./guild"),
    User: require("./user")
};