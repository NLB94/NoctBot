const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    userID: String,
    isPremium: {
        "type": Boolean,
        "default": false
    },
    lastVote: {
        "type": Date,
        "default": 0
    }
}); 

module.exports = mongoose.model("User", userSchema);