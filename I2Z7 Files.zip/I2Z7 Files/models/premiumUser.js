const mongoose = require("mongoose");

const userSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    userID: String,
    isPremium: {
        "type": Object,
        "default": false
    },
    premiumBegin: {
      "type": Date,
        "default": 0
    },
    premiumDuration: {
      "type": Date,
        "default": 0
    },
    lastVote: {
        "type": Date,
        "default": 0
    },
    
}); 

module.exports = mongoose.model("User", userSchema);