const { MESSAGES } = require("../../util/constants");

module.exports.run = (client, message, args) => {
   if (message.guild.me.hasPermission('MANAGE_MESSAGES')) message.delete();
    message.channel.send(args.join(" "));
  };
  
  
  
  module.exports.help = MESSAGES.COMMANDS.OTHER.SAY;