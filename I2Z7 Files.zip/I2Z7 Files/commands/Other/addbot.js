const { MessageEmbed } = require("discord.js");
const { MESSAGES } = require("../../util/constants");

module.exports.run = (client, message, args) => {
const embed = new MessageEmbed()
.setDescription('[Add Me](https://discord.com/oauth2/authorize?client_id=735824367698837555&permissions=2146958847&response_type=code&scope=identify%20applications.commands%20bot%20guilds%20guilds.join) | [Support server](https://discord.gg/92ffufA)')
message.channel.send(embed);
};



module.exports.help = MESSAGES.COMMANDS.OTHER.ADDBOT;