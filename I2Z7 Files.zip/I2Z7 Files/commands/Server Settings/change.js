const { MessageEmbed } = require("discord.js");
const { MESSAGES } = require("../../util/constants");
 
module.exports.run = async (client, message, args) => {
    const settings = await client.getGuild(message.guild);
    const getSetting = args[0].toLowerCase();
    let newSetting = args.slice(1).join(" ");
   //const logs = client.channels.cache.get('789919985307746304');
   const keys = ["logs", "prefix", "banMessage"]
 
    switch(getSetting) {
        case "keys": {
            const embed = new MessageEmbed()
            .setAuthor(client.user.tag, client.user.avatarURL(), 'https://discord.com/oauth2/authorize?client_id=735824367698837555&permissions=2146958847&response_type=code&scope=identify%20applications.commands%20bot%20guilds%20guilds.join')
            .setTitle('Config Keys')
            .setURL('https://discord.gg/unRX2SUcvw')
           .setTimestamp()
           .setDescription(`If you need help, join [support server](https://discord.gg/unRX2SUcvw). \n\nAvailable Keys : \n${keys.join(", ")}`)
           .setFooter(`Requested by ${message.author.tag} in ${message.guild.name}`, message.guild.iconURL());

           message.channel.send(embed);
           break;
        }
        case "logs": {
            if (newSetting) {
                const channel = isNaN(args[1]) ? (args[0].startsWith('<#') && args[0].endsWith('>') ? message.mentions.channels.first().id : (message.guild.channels.cache.find(c => c.name.toLowerCase() == newSetting.toLowerCase()) == undefined ? 'none' : message.guild.channels.cache.find(c => c.name.toLowerCase() == newSetting.toLowerCase()).id)) : (message.guild.channels.cache.get(args[1]) == undefined ? 'none' : args[1])
                newSetting = channel;
                if (newSetting = undefined || newSetting == 'none') return message.channel.send('Channel not found')
                await client.updateGuild(message.guild, { "general.logs": newSetting });
                return message.channel.send(`Logs channel changed : \nOld logs channel : \`${settings.general.logs}\` \nNew logs channel : \`${newSetting}\``);
            }
            message.channel.send(`Logs channel in this server : \`${settings.general.logs}\``);
            break;
        }
        case "money": {
            if (newSetting) {
                newSetting = newSetting.slice(0, 2);
                await client.updateGuild(message.guild, { "economy.money": newSetting });
                return message.channel.send(`Logs channel changed : \nOld logs channel : \`${settings.general.logs}\` \nNew logs channel : \`${newSetting}\``);
            }
            message.channel.send(`Logs channel in this server : \`${settings.general.logs}\``);
            break;
        }
        case "prefix": {
            if (newSetting) {
                if (newSetting.length > 4) message.channel.send(`Limit characters of prefix is 4, so prefix is ${newSetting.slice(0, 4)}`)
                newSetting = newSetting.slice(0, 4)
                await client.updateGuild(message.guild, { "general.prefix": newSetting });
                return message.channel.send(`Prefix changed : \nOld Prefix : \`${settings.general.prefix}\` \nNew Prefix : \`${newSetting}\``);
            }
            message.channel.send(`Prefix in this server : \`${settings.general.prefix}\``);
            break;
        }
        case ("banmsg" || "banmessage" || "ban-message" || "ban-msg"): {
            if (newSetting) {
                if (newSetting.length > 100) message.channel.send(`Limit characters of ban message is 75, so ban message is ${newSetting.slice(0, 75)}`);
                newSetting = newSetting.slice(0, 75);
                await client.updateGuild(message.guild, { "moderation.banMsg": newSetting});
                return message.channel.send(`Ban Message is now : \`${newSetting}\``)
            }
            message.channel.send(`Ban Message is : \`${settings.moderation.banMsg}\``);
            break;
        }
        // case "welcomeMessage": {
        //     if (newSetting) {
        //         await client.updateGuild(message.guild, { welcomeMessage: newSetting });
        //         return message.channel.send(`Welcome message changed : \nOld welcomeMessage : \`${settings.welcomeMessage}\` \nNew welcome message : \`${newSetting}\``));
        //     }
        //     message.channel.send(`Welcome message in this server : \`${settings.welcomeMessage}\``);
        //     break;
        // }
    }
};
 
module.exports.help = MESSAGES.COMMANDS.SERVERSETTINGS.CHANGE;