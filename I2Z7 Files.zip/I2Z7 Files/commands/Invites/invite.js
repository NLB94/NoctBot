const { MESSAGES } = require("../../util/constants");
const { Client } = require('@statscell/brawl');

module.exports.run = async (client, message, args) => {
    
const bs = new Client({ token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImZiODY4NzMwLWUzMDYtNDk2Yi1iMDI2LThhOTg3NGFkM2RmZSIsImlhdCI6MTYxMDc0MTA3OSwic3ViIjoiZGV2ZWxvcGVyL2ZkOGUwNWRiLTAzZGQtOTZjMC0xNTk2LTYyZGM1ZTY5MGExMCIsInNjb3BlcyI6WyJicmF3bHN0YXJzIl0sImxpbWl0cyI6W3sidGllciI6ImRldmVsb3Blci9zaWx2ZXIiLCJ0eXBlIjoidGhyb3R0bGluZyJ9LHsiY2lkcnMiOlsiOTIuOTAuMTE1LjIwIl0sInR5cGUiOiJjbGllbnQifV19.zvMwf_XTu4ltzvhw1PisGZt0RK_Uq_YAp2GoPvBd1G98p4rotQWOOZlBApxA00M3H8a1K34KvR2bHnEs08_jtg' });
 
bs.getPlayer(args[0])
  .then((player) => {
   message.channel.send(`${player.name} - ${player.tag}`);
  })
  .catch((err) => console.log(err));
};



module.exports.help = MESSAGES.COMMANDS.OTHER.PING;