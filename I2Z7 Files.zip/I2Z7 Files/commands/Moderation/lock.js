const { MESSAGES } = require('../../util/constants');

module.exports.run = async (client, message, args) => {
    const settings = await client.getGuild(message.guild);
    const position = await settings.lockChannels.map((c) => c.channelID).indexOf(message.channel.id);
    const channel = await settings.lockChannels[position];
    if (position !== -1) {
        if (channel.isLock) return message.channel.send('This channel is already lock !');
    }
        message.guild.roles.cache.forEach(async role => {
            if (role.permissions.has('MANAGE_MESSAGES')) return;
            else {
            await message.channel.updateOverwrite(role.id, { SEND_MESSAGES: false })
        }
        });

        message.channel.edit({name: `🔒_${message.channel.name}`})
       client.lockChannel(message.guild, message.channel, settings, { "lockChannels.$.isLock": true });
       message.channel.send({ embed: { description: '🔒 - Locked Channel' } });
}

module.exports.help = MESSAGES.COMMANDS.MODERATION.LOCK;