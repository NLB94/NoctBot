const { MESSAGES } = require("../../util/constants");

module.exports.run = (client, message, args) => {
    const channel = message.channel;
    if (channel.id == message.guild.rulesChannelID) return message.channel.send("This channel is the rules channel, so I can't nuke!");
    else if (channel.id == message.guild.systemChannelID) return message.channel.send("This channel is a system channel, so I can't nuke!");
    else if (channel.id == message.guild.publicUpdatesChannelID) return message.channel.send("This channel is an update channel, so I can't nuke!");
    switch (channel.type) {
        case 'news': {
            if (channel.type == 'news') {
                return message.channel.send('This channel is a news channel, so I can\'t nuke.');
            }
            break;
        }
        case 'store': {
            if (channel.type == 'store') {
                return message.channel.send('This channel is a store channel, so I can\'t nuke.');
            }
            break;
        }
        case 'text': {
            if (channel.type == 'text') {
                const position = channel.position;
                const name = channel.name;
                channel.send('Nuking...');

                channel.clone({ name: 'Nuking...' }).then(c => {
                    channel.delete('Nuked this channel');
                    c.send('Successfully nuked this channel!').then(msg => {
                        setTimeout(() => {
                            if (message.guild.me.hasPermission('MANAGE_MESSAGES')) {
                                msg.delete();
                            }
                            else return;
                        }, 10000);
                    }).catch(() => '');
                    setTimeout(() => {
                        c.edit({ name: `${name}`, position: position })
                    }, 3000);
                });

            }
            break;
        };
    };
}

module.exports.help = MESSAGES.COMMANDS.MODERATION.NUKE;